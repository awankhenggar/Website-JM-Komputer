@extends('layouts.app')
@section('title', $product->name)
@section('content')
<p class="mb-4 text-sm text-stone-600"><a href="{{ route('products.index') }}" class="underline">Produk</a> / {{ $product->category->name ?? '' }} / {{ $product->name }}</p>
<div class="grid gap-8 md:grid-cols-2">
    <div>
        @if ($product->image_url)
            <img src="{{ $product->image_url }}" alt="{{ $product->name }}" data-cart-product-image class="w-full rounded-xl border border-stone-300 object-cover">
        @else
            <div class="flex h-80 items-center justify-center rounded-xl bg-stone-200 text-stone-600">Foto produk</div>
        @endif
    </div>
    <div class="flex flex-col gap-3">
        <h1 class="text-2xl font-bold">{{ $product->name }}</h1>
        <b class="text-2xl">@rp($product->price)</b>
        @if ($avgRating)
            <a href="#ulasan" class="text-sm underline">&#9733; {{ $avgRating }} ({{ $reviewCount }} ulasan)</a>
        @endif
        <span class="text-sm text-stone-700">Kategori: {{ $product->category->name ?? '-' }} &middot; Berat: {{ $product->weight_gram }} g</span>
        @if ($product->stock > 0)
            <span class="chip w-fit">Stok tersedia: {{ $product->stock }}</span>
            <form method="POST" action="{{ route('cart.add', $product) }}" data-cart-add class="flex items-end gap-3">
                @csrf
                <label class="text-sm">Jumlah<input class="input mt-1 w-24" type="number" name="qty" value="1" min="1" max="{{ $product->stock }}"></label>
                <button class="btn btn-primary" type="submit">Tambah ke Keranjang</button>
            </form>
        @else
            <span class="chip w-fit">Stok habis</span>
            <button class="btn" type="button" disabled>Stok Habis</button>
        @endif
        <a class="btn" target="_blank" rel="noopener" href="https://wa.me/{{ config('store.whatsapp') }}?text={{ urlencode('Halo, saya ingin bertanya tentang '.$product->name) }}">Konsultasi via WhatsApp</a>
    </div>
</div>
<div class="mt-8 grid gap-4 md:grid-cols-2">
    <div class="card"><b>Deskripsi</b><p class="mt-2 whitespace-pre-line text-sm">{{ $product->description ?: 'Belum ada deskripsi.' }}</p></div>
    <div class="card"><b>Spesifikasi</b><p class="mt-2 whitespace-pre-line text-sm">{{ $product->specs ?: 'Belum ada spesifikasi.' }}</p></div>
</div>
<section id="ulasan" class="mt-8">
    <h2 class="mb-3 text-xl font-bold">Ulasan Produk @if ($avgRating)<span class="text-base font-normal">&#9733; {{ $avgRating }} dari {{ $reviewCount }} ulasan</span>@endif</h2>
    @forelse ($reviews as $r)
        <div class="card mb-3 text-sm">
            <div class="flex flex-wrap items-center justify-between gap-2"><b>{{ \Illuminate\Support\Str::before($r->user->name, ' ') }}</b><span>{{ $r->stars() }}</span></div>
            <span class="text-xs text-stone-600">{{ $r->created_at->format('d/m/Y') }} &middot; Pembelian terverifikasi</span>
            @if ($r->comment)<p class="mt-1 whitespace-pre-line">{{ $r->comment }}</p>@endif
            @if ($r->photo_url)<img src="{{ $r->photo_url }}" alt="Foto ulasan" class="mt-2 h-24 rounded">@endif
            @if ($r->admin_reply)<div class="mt-2 rounded-lg bg-stone-100 p-2"><b class="text-xs">Balasan toko</b><p>{{ $r->admin_reply }}</p></div>@endif
        </div>
    @empty
        <p class="text-sm">Belum ada ulasan. Ulasan bisa ditulis pembeli setelah pesanan selesai.</p>
    @endforelse
    @if ($reviewCount > 5)<a class="btn" href="{{ route('reviews.index', ['produk' => $product->id]) }}">Lihat Semua Ulasan</a>@endif
</section>
@if ($related->isNotEmpty())
    <h2 class="mb-4 mt-10 text-xl font-bold">Produk Terkait</h2>
    <div class="grid grid-cols-2 gap-4 md:grid-cols-4">
        @foreach ($related as $p)
            @include('partials.product-card', ['product' => $p])
        @endforeach
    </div>
@endif
@endsection
