@extends('layouts.app')
@section('title', 'Produk')
@section('content')
<h1 class="mb-6 text-3xl font-bold">Produk</h1>
<div class="flex flex-col gap-6 md:flex-row">
    <form method="GET" action="{{ route('products.index') }}" class="card flex flex-col gap-3 self-start md:w-60">
        <b>Filter</b>
        <label class="text-sm">Cari<input class="input mt-1" type="search" name="q" value="{{ request('q') }}"></label>
        <label class="text-sm">Kategori
            <select class="input mt-1" name="kategori">
                <option value="">Semua kategori</option>
                @foreach ($categories as $c)
                    <option value="{{ $c->slug }}" @selected(request('kategori') === $c->slug)>{{ $c->name }}</option>
                @endforeach
            </select>
        </label>
        <label class="text-sm">Urutkan
            <select class="input mt-1" name="urut">
                <option value="">Terbaru</option>
                <option value="termurah" @selected(request('urut') === 'termurah')>Harga terendah</option>
                <option value="termahal" @selected(request('urut') === 'termahal')>Harga tertinggi</option>
            </select>
        </label>
        <button class="btn btn-primary" type="submit">Terapkan</button>
        <a class="btn" href="{{ route('products.index') }}">Reset</a>
    </form>
    <div class="flex-1">
        <p class="mb-3 text-sm text-stone-700">{{ $products->total() }} produk</p>
        @if ($products->isEmpty())
            <div class="card text-center">
                <b>Tidak ada hasil</b>
                <p class="mt-1 text-sm">Periksa ejaan, kurangi filter, atau tanyakan langsung ke kami.</p>
                <div class="mt-3 flex justify-center gap-3"><a class="btn" href="{{ route('products.index') }}">Hapus Filter</a><a class="btn btn-accent" target="_blank" rel="noopener" href="https://wa.me/{{ config('store.whatsapp') }}?text={{ urlencode('Halo, saya mencari produk: '.request('q')) }}">Tanya via WhatsApp</a></div>
            </div>
        @else
            <div class="grid grid-cols-2 gap-4 lg:grid-cols-3">
                @foreach ($products as $product)
                    @include('partials.product-card', ['product' => $product])
                @endforeach
            </div>
            <div class="mt-6">{{ $products->links() }}</div>
        @endif
    </div>
</div>
@endsection
