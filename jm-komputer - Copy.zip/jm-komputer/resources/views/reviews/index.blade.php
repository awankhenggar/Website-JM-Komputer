
@extends('layouts.app')

@section('title', 'Ulasan Pelanggan')

@section('content')
<h1 class="mb-2 text-3xl font-bold">Ulasan Pelanggan</h1>
<p class="mb-6 text-sm text-stone-700">
    Ulasan ditulis oleh pembeli yang pesanannya sudah selesai.
</p>

<div class="flex flex-col gap-6 md:flex-row">
    <aside class="card self-start md:w-72">
        <b class="text-3xl">&#9733; {{ $avg }}</b>
        <span class="text-sm text-stone-600">dari {{ $total }} ulasan</span>

        @foreach ([5, 4, 3, 2, 1] as $star)
            @php
                $c = (int) ($dist[$star] ?? 0);
                $pct = $total ? round($c / $total * 100) : 0;
            @endphp

            <div class="flex items-center gap-2 text-sm">
                <span class="w-8">{{ $star }} &#9733;</span>
                <div class="h-2 flex-1 rounded bg-stone-200">
                    <div class="h-2 rounded bg-brand" style="width: {{ $pct }}%"></div>
                </div>
                <span class="w-6 text-right text-xs">{{ $c }}</span>
            </div>
        @endforeach
    </aside>

    <div class="flex-1">
        <form method="GET" class="mb-4 flex flex-wrap gap-3">
            <select class="input w-56" name="produk" aria-label="Produk">
                <option value="">Semua produk</option>
                @foreach ($products as $p)
                    <option value="{{ $p->id }}" @selected(request('produk') == $p->id)>
                        {{ $p->name }}
                    </option>
                @endforeach
            </select>

            <select class="input w-40" name="bintang" aria-label="Bintang">
                <option value="">Semua bintang</option>
                @foreach ([5, 4, 3, 2, 1] as $s)
                    <option value="{{ $s }}" @selected(request('bintang') == $s)>
                        {{ $s }} bintang
                    </option>
                @endforeach
            </select>

            <button class="btn" type="submit">Filter</button>
        </form>

        @forelse ($reviews as $r)
            <div class="card mb-3 text-sm">
                <div class="flex flex-wrap items-center justify-between gap-2">
                    <b>{{ \Illuminate\Support\Str::before($r->user->name, ' ') }}</b>
                    <span>{{ $r->stars() }}</span>
                </div>

                <span class="text-xs text-stone-600">
                    {{ $r->created_at->format('d/m/Y') }} &middot; Pembelian terverifikasi

                    @if ($r->product)
                        &middot;
                        <a class="underline" href="{{ route('products.show', $r->product->slug) }}">
                            {{ $r->product->name }}
                        </a>
                    @endif
                </span>

                @if ($r->comment)
                    <p class="mt-1 whitespace-pre-line">{{ $r->comment }}</p>
                @endif

                @if ($r->photo_url)
                    <img src="{{ $r->photo_url }}" alt="Foto ulasan" class="mt-2 h-24 rounded">
                @endif

                @if ($r->admin_reply)
                    <div class="mt-2 rounded-lg bg-stone-100 p-2">
                        <b class="text-xs">Balasan toko</b>
                        <p>{{ $r->admin_reply }}</p>
                    </div>
                @endif
            </div>
        @empty
            <div class="card text-center text-sm">
                Belum ada ulasan. Ulasan bisa ditulis pembeli setelah pesanan selesai.
            </div>
        @endforelse

        <div class="mt-4">
            {{ $reviews->links() }}
        </div>
    </div>
</div>
@endsection
