@extends('layouts.app')
@section('title', 'Tulis Ulasan')
@section('content')
<h1 class="mb-6 text-3xl font-bold">Tulis Ulasan</h1>
<form method="POST" action="{{ route('account.reviews.store', $item) }}" enctype="multipart/form-data" class="card grid max-w-xl gap-4">
    @csrf
    <div class="text-sm"><b>{{ $item->name }}</b><br><span class="text-stone-600">Pesanan {{ $item->order->code }}</span></div>
    <fieldset>
        <legend class="mb-1 text-sm font-medium">Rating</legend>
        <div class="flex flex-wrap gap-4">
            @foreach ([1, 2, 3, 4, 5] as $s)
                <label class="flex items-center gap-1 text-sm"><input type="radio" name="rating" value="{{ $s }}" @checked(old('rating') == $s) required> {{ $s }} &#9733;</label>
            @endforeach
        </div>
        @error('rating')<p class="mt-1 text-sm text-red-700" role="alert">{{ $message }}</p>@enderror
    </fieldset>
    <x-field name="comment" label="Komentar (opsional)" type="textarea" :rows="4" />
    <x-field name="photo" label="Foto (opsional, maks 2 MB)" type="file" accept="image/*" />
    <p class="text-xs text-stone-600">Ulasan langsung tampil di website dengan nama depan Anda.</p>
    <div class="flex gap-3"><button class="btn btn-primary" type="submit">Kirim Ulasan</button><a class="btn" href="{{ route('account.orders.show', $item->order_id) }}">Batal</a></div>
</form>
@endsection
