@extends('layouts.app')
@section('title', 'Booking Servis')
@section('content')
<h1 class="mb-6 text-3xl font-bold">Booking Servis</h1>
<div class="grid gap-6 md:grid-cols-3">
    <form method="POST" action="{{ route('booking.store') }}" class="card grid gap-4 md:col-span-2">
        @csrf
        <x-select name="service_type" label="Jenis booking" :options="['umum' => 'Servis umum', 'garansi' => 'Klaim garansi produk dari toko ini']" :value="old('service_type', 'umum')" />
        <x-select name="order_id" label="Pesanan terkait (khusus klaim garansi)" :options="$orders->mapWithKeys(fn ($o) => [$o->id => $o->code.' - '.$o->created_at->format('d/m/Y')])->all()" blank="Tidak ada" />
        <x-select name="device_type" label="Jenis perangkat" :options="['Laptop' => 'Laptop', 'PC / Komputer' => 'PC / Komputer', 'Lainnya' => 'Lainnya']" />
        <x-field name="brand_model" label="Merek dan tipe perangkat" required />
        <x-field name="complaint" label="Keluhan / kerusakan" type="textarea" :rows="4" />
        <x-select name="handover" label="Cara penyerahan" :options="['datang' => 'Datang ke toko', 'kurir' => 'Kirim via kurir']" />
        <x-field name="visit_date" label="Tanggal kunjungan (opsional)" type="date" />
        <button class="btn btn-accent" type="submit">Kirim Booking</button>
    </form>
    <aside class="card self-start text-sm">
        <b>Informasi</b>
        <p class="mt-2">{{ config('store.address') }}<br>{{ config('store.hours') }}</p>
        <p class="mt-2">Setelah booking, Anda mendapat nomor servis dan bisa memantau statusnya di Akun Saya. Perangkat yang sudah selesai harap diambil maksimal 30 hari. Pembayaran dilakukan setelah servis selesai.</p>
    </aside>
</div>
@endsection
