@extends('layouts.app')
@section('title', 'Keranjang')
@section('content')
<h1 class="mb-6 text-3xl font-bold">Keranjang</h1>
@if ($items->isEmpty())
    <div class="card text-center"><b>Keranjang masih kosong</b><p class="mt-1 text-sm">Tambahkan produk untuk mulai berbelanja.</p><a class="btn btn-primary mt-3" href="{{ route('products.index') }}">Mulai Belanja</a></div>
@else
    <div class="card">
        <form id="cart-update-form" method="POST" action="{{ route('cart.update-all') }}">
            @csrf
            @method('PATCH')
        </form>
        <form id="cart-checkout-form" method="GET" action="{{ route('checkout.show') }}"></form>

        <div class="mb-4 flex flex-wrap items-center justify-between gap-2">
            <p class="text-sm text-stone-600">Centang produk yang ingin dibeli. Produk yang tidak dipilih akan tetap berada di keranjang.</p>
        </div>

        <div class="overflow-x-auto">
            <table class="tbl">
                <tr><th>Pilih</th><th>Produk</th><th>Harga</th><th>Jumlah</th><th>Subtotal</th><th></th></tr>
                @foreach ($items as $item)
                    <tr>
                        <td>
                            <input
                                type="checkbox"
                                name="selected[]"
                                value="{{ $item['product']->id }}"
                                form="cart-checkout-form"
                                checked
                                aria-label="Pilih {{ $item['product']->name }} untuk checkout"
                            >
                        </td>
                        <td><a class="font-semibold underline" href="{{ route('products.show', $item['product']->slug) }}">{{ $item['product']->name }}</a><br><span class="text-xs text-stone-600">Stok {{ $item['product']->stock }}</span></td>
                        <td>@rp($item['product']->price)</td>
                        <td>
                            <input
                                class="input w-20"
                                type="number"
                                name="qty[{{ $item['product']->id }}]"
                                value="{{ $item['qty'] }}"
                                min="1"
                                max="{{ max(1, $item['product']->stock) }}"
                                form="cart-update-form"
                                aria-label="Jumlah {{ $item['product']->name }}"
                            >
                        </td>
                        <td>@rp($item['product']->price * $item['qty'])</td>
                        <td><form method="POST" action="{{ route('cart.remove', $item['product']) }}">@csrf @method('DELETE')<button class="btn" type="submit">Hapus</button></form></td>
                    </tr>
                @endforeach
            </table>
        </div>

        <div class="mt-4 flex flex-wrap items-center justify-between gap-3">
            <span>Ongkir dihitung oleh toko setelah pesanan dibuat.</span>
            <div class="text-right"><span class="text-sm">Subtotal seluruh keranjang</span><br><b class="text-xl">@rp($subtotal)</b></div>
        </div>
        <div class="mt-4 flex flex-wrap justify-end gap-3">
            <a class="btn" href="{{ route('products.index') }}">Lanjut Belanja</a>
            <button class="btn btn-primary" type="submit" form="cart-update-form">Perbarui Keranjang</button>
            <button class="btn btn-accent" type="submit" form="cart-checkout-form">Checkout Produk Dipilih</button>
        </div>
    </div>
@endif
@endsection
