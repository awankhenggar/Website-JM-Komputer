@extends('layouts.app')
@section('title', 'Ajukan Pembatalan / Retur')
@section('content')
<h1 class="mb-6 text-3xl font-bold">Ajukan Pembatalan / Retur</h1>
<div class="grid gap-6 md:grid-cols-3">
    <form method="POST" action="{{ route('account.returns.store', $order) }}" enctype="multipart/form-data" class="card grid gap-4 md:col-span-2">
        @csrf
        <b>Pesanan {{ $order->code }}</b>
        <fieldset>
            <legend class="mb-1 text-sm font-medium">Jenis pengajuan</legend>
            @foreach ($types as $t)
                <label class="mb-1 flex items-center gap-2 text-sm"><input type="radio" name="type" value="{{ $t }}" @checked(old('type', $types[0]) === $t) required> {{ \App\Models\ReturnRequest::TYPES[$t] }}</label>
            @endforeach
            @error('type')<p class="mt-1 text-sm text-red-700" role="alert">{{ $message }}</p>@enderror
        </fieldset>
        <x-select name="reason" label="Alasan" :options="['Barang rusak / cacat' => 'Barang rusak / cacat', 'Tidak sesuai pesanan' => 'Tidak sesuai pesanan', 'Berubah pikiran' => 'Berubah pikiran', 'Lainnya' => 'Lainnya']" />
        <x-field name="description" label="Keterangan" type="textarea" :rows="4" />
        <x-field name="photo" label="Foto bukti (wajib untuk retur, maks 3 MB)" type="file" accept="image/*" />
        <div class="flex gap-3"><button class="btn btn-primary" type="submit">Kirim Pengajuan</button><a class="btn" href="{{ route('account.orders.show', $order) }}">Batal</a></div>
    </form>
    <aside class="card self-start bg-stone-50 text-sm">
        <b>Ketentuan</b>
        <p class="mt-2">Pembatalan hanya untuk pesanan yang sudah dibayar dan belum dikirim.</p>
        <p class="mt-2">Retur maksimal {{ config('store.return_days') }} hari setelah pesanan selesai. Barang harus lengkap dan disertai foto bukti.</p>
        <p class="mt-2">Pengajuan ditinjau toko. Refund diproses manual sesuai keputusan toko.</p>
    </aside>
</div>
@endsection
