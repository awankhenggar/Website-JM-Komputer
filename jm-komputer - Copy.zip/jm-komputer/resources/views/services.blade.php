@extends('layouts.app')
@section('title', 'Layanan Servis')
@section('content')
<h1 class="mb-2 text-3xl font-bold">Servis Laptop &amp; Komputer</h1>
<p class="mb-6 text-sm text-stone-700">Estimasi biaya diberikan setelah diagnosa. Anda menyetujui estimasi sebelum perangkat dikerjakan, dan membayar setelah servis selesai.</p>
<div class="mb-8 grid gap-4 md:grid-cols-3">
    @forelse ($items as $item)
        <div class="card">
            <b>{{ $item->name }}</b>
            @if ($item->description)<p class="mt-1 text-sm">{{ $item->description }}</p>@endif
            <p class="mt-2 text-xs text-stone-600">
                @if ($item->price_from)Mulai @rp($item->price_from)@else Biaya dari hasil diagnosa @endif
                @if ($item->est_days) &middot; Estimasi {{ $item->est_days }} hari @endif
            </p>
        </div>
    @empty
        @foreach (['Ganti layar', 'Ganti baterai / keyboard', 'Upgrade RAM / SSD', 'Install ulang OS & software', 'Pembersihan & thermal paste', 'Mati total / motherboard'] as $svc)
            <div class="card"><b>{{ $svc }}</b><p class="mt-1 text-xs text-stone-600">Biaya dan waktu: dari hasil diagnosa.</p></div>
        @endforeach
    @endforelse
</div>
<div class="card mb-8">
    <h2 class="text-xl font-bold">Ketentuan</h2>
    <ul class="mt-2 list-disc pl-5 text-sm">
        @if (config('store.warranty_days'))<li>Garansi servis {{ config('store.warranty_days') }} hari.</li>@endif
        <li>Jika biaya akhir melebihi estimasi lebih dari 20 persen, kami meminta persetujuan Anda lagi.</li>
        <li>Perangkat yang sudah selesai harap diambil maksimal 30 hari.</li>
        <li>Klaim garansi produk dari toko ini bisa diajukan lewat form booking.</li>
    </ul>
</div>
<div class="flex gap-3"><a class="btn btn-primary" href="{{ route('booking.create') }}">Booking Servis</a><a class="btn" target="_blank" rel="noopener" href="https://wa.me/{{ config('store.whatsapp') }}?text={{ urlencode('Halo, saya ingin konsultasi servis.') }}">Konsultasi via WhatsApp</a></div>
@endsection
