@extends('layouts.admin')
@section('title', 'Produk & Stok')
@section('content')
<div class="mb-6 flex items-center justify-between"><h1 class="text-2xl font-bold">Produk &amp; Stok</h1><a class="btn btn-primary" href="{{ route('admin.produk.create') }}">+ Tambah Produk</a></div>
<form method="GET" class="mb-4 flex flex-wrap gap-3">
    <input class="input w-64" type="search" name="q" value="{{ request('q') }}" placeholder="Cari produk" aria-label="Cari produk">
    <select class="input w-56" name="kategori" aria-label="Kategori"><option value="">Semua kategori</option>@foreach ($categories as $c)<option value="{{ $c->id }}" @selected(request('kategori') == $c->id)>{{ $c->name }}</option>@endforeach</select>
    <button class="btn" type="submit">Filter</button>
</form>
<div class="card overflow-x-auto">
    <table class="tbl">
        <tr><th>Foto</th><th>Produk</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Status</th><th>Aksi</th></tr>
        @forelse ($products as $p)
            <tr>
                <td>@if ($p->image_url)<img src="{{ $p->image_url }}" alt="" class="h-10 w-12 rounded object-cover">@else<div class="h-10 w-12 rounded bg-stone-200"></div>@endif</td>
                <td>{{ $p->name }}</td><td>{{ $p->category->name ?? '-' }}</td><td>@rp($p->price)</td>
                <td>{{ $p->stock }} @if ($p->stock <= 3)<span class="chip">Menipis</span>@endif</td>
                <td><span class="chip">{{ $p->is_active ? 'Aktif' : 'Nonaktif' }}</span></td>
                <td class="flex gap-3"><a class="underline" href="{{ route('admin.produk.edit', $p) }}">Ubah</a>
                    <form method="POST" action="{{ route('admin.produk.destroy', $p) }}" onsubmit="return confirm('Hapus produk ini?')">@csrf @method('DELETE')<button class="underline" type="submit">Hapus</button></form></td>
            </tr>
        @empty
            <tr><td colspan="7">Belum ada produk.</td></tr>
        @endforelse
    </table>
    <div class="mt-4">{{ $products->links() }}</div>
</div>
@endsection
