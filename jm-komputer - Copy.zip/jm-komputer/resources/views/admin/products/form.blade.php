@extends('layouts.admin')
@section('title', $product->exists ? 'Ubah Produk' : 'Tambah Produk')
@section('content')
<h1 class="mb-6 text-2xl font-bold">{{ $product->exists ? 'Ubah' : 'Tambah' }} Produk</h1>
<form method="POST" enctype="multipart/form-data" action="{{ $product->exists ? route('admin.produk.update', $product) : route('admin.produk.store') }}" class="card grid max-w-2xl gap-4">
    @csrf
    @if ($product->exists) @method('PUT') @endif
    <x-select name="category_id" label="Kategori" :options="$categories->pluck('name', 'id')->all()" :value="$product->category_id" blank="Pilih kategori" />
    <x-field name="name" label="Nama produk" :value="$product->name" required />
    <x-field name="description" label="Deskripsi" type="textarea" :value="$product->description" :rows="4" />
    <x-field name="specs" label="Spesifikasi (satu per baris)" type="textarea" :value="$product->specs" :rows="4" />
    <div class="grid gap-4 md:grid-cols-3">
        <x-field name="price" label="Harga (Rp)" type="number" :value="$product->price" min="0" required />
        <x-field name="stock" label="Stok" type="number" :value="$product->stock" min="0" required />
        <x-field name="weight_gram" label="Berat (gram)" type="number" :value="$product->weight_gram" min="1" required />
    </div>
    <div>
        <x-field name="image" label="Foto produk (maks 2 MB)" type="file" accept="image/*" />
        @if ($product->image_url)<img src="{{ $product->image_url }}" alt="Foto saat ini" class="mt-2 h-24 rounded">@endif
    </div>
    <x-check name="is_active" label="Tampilkan di toko" :checked="(bool) $product->is_active" />
    <x-check name="is_featured" label="Jadikan produk unggulan di beranda" :checked="(bool) $product->is_featured" />
    <div class="flex gap-3"><button class="btn btn-primary" type="submit">Simpan</button><a class="btn" href="{{ route('admin.produk.index') }}">Batal</a></div>
</form>
@endsection
