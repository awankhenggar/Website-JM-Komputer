@extends('layouts.admin')
@section('title', $item->exists ? 'Ubah Layanan' : 'Tambah Layanan')
@section('content')
<h1 class="mb-6 text-2xl font-bold">{{ $item->exists ? 'Ubah' : 'Tambah' }} Layanan</h1>
<form method="POST" action="{{ $item->exists ? route('admin.layanan.update', $item) : route('admin.layanan.store') }}" class="card grid max-w-xl gap-4">
    @csrf
    @if ($item->exists) @method('PUT') @endif
    <x-field name="name" label="Nama layanan" :value="$item->name" required />
    <x-field name="description" label="Deskripsi singkat" type="textarea" :value="$item->description" :rows="3" />
    <div class="grid gap-4 md:grid-cols-3">
        <x-field name="price_from" label="Biaya mulai (Rp)" type="number" :value="$item->price_from" min="0" />
        <x-field name="est_days" label="Estimasi (hari)" type="number" :value="$item->est_days" min="0" />
        <x-field name="sort_order" label="Urutan" type="number" :value="$item->sort_order" min="0" required />
    </div>
    <x-check name="is_active" label="Tampilkan di website" :checked="(bool) $item->is_active" />
    <div class="flex gap-3"><button class="btn btn-primary" type="submit">Simpan</button><a class="btn" href="{{ route('admin.layanan.index') }}">Batal</a></div>
</form>
@endsection
