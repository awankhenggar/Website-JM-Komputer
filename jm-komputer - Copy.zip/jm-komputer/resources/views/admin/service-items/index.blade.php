@extends('layouts.admin')
@section('title', 'Layanan Servis')
@section('content')
<div class="mb-6 flex items-center justify-between"><h1 class="text-2xl font-bold">Layanan Servis</h1><a class="btn btn-primary" href="{{ route('admin.layanan.create') }}">+ Tambah Layanan</a></div>
<p class="mb-4 text-sm text-stone-700">Tampil di halaman Layanan Servis. Garansi servis diatur di Pengaturan Toko.</p>
<div class="card overflow-x-auto">
    <table class="tbl">
        <tr><th>Layanan</th><th>Biaya mulai</th><th>Estimasi</th><th>Urutan</th><th>Status</th><th>Aksi</th></tr>
        @forelse ($items as $i)
            <tr><td>{{ $i->name }}</td><td>@if ($i->price_from)@rp($i->price_from)@else - @endif</td><td>@if ($i->est_days){{ $i->est_days }} hari @else - @endif</td><td>{{ $i->sort_order }}</td>
                <td><span class="chip">{{ $i->is_active ? 'Tampil' : 'Disembunyikan' }}</span></td>
                <td class="flex gap-3"><a class="underline" href="{{ route('admin.layanan.edit', $i) }}">Ubah</a>
                    <form method="POST" action="{{ route('admin.layanan.destroy', $i) }}" onsubmit="return confirm('Hapus layanan ini?')">@csrf @method('DELETE')<button class="underline" type="submit">Hapus</button></form></td></tr>
        @empty
            <tr><td colspan="6">Belum ada layanan.</td></tr>
        @endforelse
    </table>
</div>
@endsection
