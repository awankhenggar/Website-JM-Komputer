@extends('layouts.admin')
@section('title', 'Pesanan '.$order->code)
@section('content')
<div class="mb-6 flex items-center gap-3"><h1 class="text-2xl font-bold">Pesanan {{ $order->code }}</h1><x-status :model="$order" /></div>
<div class="grid gap-6 lg:grid-cols-3">
    <div class="card overflow-x-auto lg:col-span-2">
        <b>Item pesanan</b>
        <table class="tbl mt-2"><tr><th>Produk</th><th>Jumlah</th><th>Harga</th></tr>
            @foreach ($order->items as $i)<tr><td>{{ $i->name }}</td><td>{{ $i->qty }}</td><td>@rp($i->price * $i->qty)</td></tr>@endforeach
        </table>
        <div class="mt-3 flex justify-between text-sm"><span>Subtotal</span><span>@rp($order->subtotal)</span></div>
        <div class="flex justify-between text-sm"><span>Ongkir</span><span>@rp($order->shipping_cost)</span></div>
        <div class="flex justify-between border-t border-stone-300 pt-2"><b>Total</b><b>@rp($order->total)</b></div>
    </div>
    <div class="flex flex-col gap-4">
        <div class="card text-sm"><b>Pelanggan</b><br>{{ $order->user->name }} &middot; {{ $order->user->email }}@unless ($order->user->hasVerifiedEmail()) <span class="chip">Email belum diverifikasi</span>@endunless<br>Penerima: {{ $order->recipient_name }} ({{ $order->phone }})<br>{{ $order->address }}, {{ $order->city }}@if ($order->notes)<br>Catatan: {{ $order->notes }}@endif
            <br><a class="underline" target="_blank" rel="noopener" href="https://wa.me/{{ preg_replace('/\D/', '', $order->phone) }}">Hubungi via WhatsApp</a></div>
        <div class="card text-sm"><b>Pembayaran</b><br>{{ ucfirst($order->payment_method) }}@if ($order->paid_at) &middot; dibayar {{ $order->paid_at->format('d/m/Y H:i') }}@endif
            @if ($order->payment_proof)<br><a class="underline" target="_blank" href="{{ asset('storage/'.$order->payment_proof) }}">Lihat bukti transfer</a>@else<br>Belum ada bukti transfer.@endif</div>
        @if ($order->status === 'batal' && $order->cancellation_note)
            <div class="card border border-rose-200 bg-rose-50 text-sm">
                <b class="text-rose-800">Catatan pembatalan admin</b>
                <p class="mt-2 whitespace-pre-line text-rose-900">{{ $order->cancellation_note }}</p>
            </div>
        @endif
        @if ($order->status !== 'batal')
            <form method="POST" action="{{ route('admin.pesanan.update', $order) }}" class="card grid gap-3">
                @csrf @method('PATCH')
                <b>Perbarui pesanan</b>
                <x-select name="status" label="Status" :options="\App\Models\Order::STATUSES" :value="$order->status" />
                <x-field name="shipping_cost" label="Ongkir (Rp)" type="number" :value="$order->shipping_cost" min="0" />
                <x-field name="tracking_number" label="Nomor resi" :value="$order->tracking_number" />
                <div data-cancellation-note-wrap class="grid gap-1">
                    <label for="cancellation_note" class="text-sm font-semibold text-slate-700">Catatan pembatalan (wajib jika status dibatalkan)</label>
                    <textarea id="cancellation_note" name="cancellation_note" rows="3" maxlength="1000" class="input w-full" placeholder="Jelaskan alasan pembatalan agar pelanggan mengetahuinya">{{ old('cancellation_note') }}</textarea>
                    @error('cancellation_note')<p class="text-xs text-rose-600">{{ $message }}</p>@enderror
                </div>
                <button class="btn btn-primary" type="submit">Simpan</button>
                <script>
                    (() => {
                        const form = document.currentScript.closest('form');
                        const status = form?.querySelector('[name="status"]');
                        const wrap = form?.querySelector('[data-cancellation-note-wrap]');
                        const note = form?.querySelector('[name="cancellation_note"]');
                        const sync = () => {
                            const cancelling = status?.value === 'batal';
                            if (wrap) wrap.style.display = cancelling ? 'grid' : 'none';
                            if (note) note.required = cancelling;
                        };
                        status?.addEventListener('change', sync);
                        sync();
                    })();
                </script>
                <span class="text-xs text-stone-600">Memilih status Dibatalkan mengembalikan stok.</span>
            </form>
        @endif
    </div>
</div>
@endsection
