@extends('layouts.admin')
@section('title', 'Pesanan')
@section('content')
<h1 class="mb-6 text-2xl font-bold">Pesanan</h1>
<form method="GET" class="mb-4 flex flex-wrap gap-3">
    <input class="input w-64" type="search" name="q" value="{{ request('q') }}" placeholder="No. pesanan atau penerima" aria-label="Cari pesanan">
    <select class="input w-56" name="status" aria-label="Status"><option value="">Semua status</option>@foreach (\App\Models\Order::STATUSES as $k => $v)<option value="{{ $k }}" @selected(request('status') === $k)>{{ $v }}</option>@endforeach</select>
    <button class="btn" type="submit">Filter</button>
</form>
<div class="card overflow-x-auto">
    <table class="tbl">
        <tr><th>No. pesanan</th><th>Pelanggan</th><th>Tanggal</th><th>Total</th><th>Status</th><th>Aksi</th></tr>
        @forelse ($orders as $o)
            <tr><td>{{ $o->code }}</td><td>{{ $o->user->name }}</td><td>{{ $o->created_at->format('d/m/Y H:i') }}</td><td>@rp($o->total)</td><td><x-status :model="$o" /></td><td><a class="underline" href="{{ route('admin.pesanan.show', $o) }}">Detail</a></td></tr>
        @empty
            <tr><td colspan="6">Belum ada pesanan.</td></tr>
        @endforelse
    </table>
    <div class="mt-4">{{ $orders->links() }}</div>
</div>
@endsection
