@extends('layouts.admin')
@section('title', 'Manajemen Admin')
@section('content')
<div class="mb-6 flex items-center justify-between"><h1 class="text-2xl font-bold">Manajemen Admin</h1><a class="btn btn-primary" href="{{ route('admin.pengguna.create') }}">+ Tambah Akun</a></div>
<div class="card overflow-x-auto">
    <table class="tbl">
        <tr><th>Nama</th><th>Email</th><th>Peran</th><th>Aksi</th></tr>
        @foreach ($staff as $u)
            <tr><td>{{ $u->name }}</td><td>{{ $u->email }}</td><td><span class="chip">{{ $u->role }}</span></td>
                <td class="flex gap-3"><a class="underline" href="{{ route('admin.pengguna.edit', $u) }}">Ubah</a>
                    @if ($u->id !== auth()->id())<form method="POST" action="{{ route('admin.pengguna.destroy', $u) }}" onsubmit="return confirm('Hapus akun ini?')">@csrf @method('DELETE')<button class="underline" type="submit">Hapus</button></form>@endif</td></tr>
        @endforeach
    </table>
</div>
<p class="mt-4 text-sm text-stone-700">Admin: semua menu. Teknisi: hanya menu Servis.</p>
@endsection
