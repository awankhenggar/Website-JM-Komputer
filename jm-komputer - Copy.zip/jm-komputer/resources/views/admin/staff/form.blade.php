@extends('layouts.admin')
@section('title', $user->exists ? 'Ubah Akun' : 'Tambah Akun')
@section('content')
<h1 class="mb-6 text-2xl font-bold">{{ $user->exists ? 'Ubah' : 'Tambah' }} Akun</h1>
<form method="POST" action="{{ $user->exists ? route('admin.pengguna.update', $user) : route('admin.pengguna.store') }}" class="card grid max-w-xl gap-4">
    @csrf
    @if ($user->exists) @method('PUT') @endif
    <x-field name="name" label="Nama" :value="$user->name" required />
    <x-field name="email" label="Email" type="email" :value="$user->email" required />
    <x-field name="phone" label="Nomor telepon" :value="$user->phone" />
    <x-select name="role" label="Peran" :options="['admin' => 'Admin', 'teknisi' => 'Teknisi']" :value="$user->role" />
    <x-field name="password" label="Password" type="password" :help="$user->exists ? 'Kosongkan jika tidak ingin mengubah password.' : 'Minimal 8 karakter.'" />
    <div class="flex gap-3"><button class="btn btn-primary" type="submit">Simpan</button><a class="btn" href="{{ route('admin.pengguna.index') }}">Batal</a></div>
</form>
@endsection
