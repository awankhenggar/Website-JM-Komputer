@extends('layouts.admin')
@section('title', 'Ulasan')
@section('content')
<h1 class="mb-6 text-2xl font-bold">Ulasan Pelanggan</h1>
<div class="mb-6 grid grid-cols-2 gap-4 md:grid-cols-3">
    <div class="card"><span class="text-xs">Total ulasan</span><b class="block text-2xl">{{ $total }}</b></div>
    <div class="card"><span class="text-xs">Rata-rata bintang (tampil)</span><b class="block text-2xl">{{ $avg }}</b></div>
</div>
<form method="GET" class="mb-4 flex flex-wrap gap-3">
    <select class="input w-44" name="status" aria-label="Status"><option value="">Semua status</option><option value="tampil" @selected(request('status') === 'tampil')>Tampil</option><option value="disembunyikan" @selected(request('status') === 'disembunyikan')>Disembunyikan</option></select>
    <select class="input w-40" name="bintang" aria-label="Bintang"><option value="">Semua bintang</option>@foreach ([5, 4, 3, 2, 1] as $s)<option value="{{ $s }}" @selected(request('bintang') == $s)>{{ $s }} bintang</option>@endforeach</select>
    <button class="btn" type="submit">Filter</button>
</form>
<p class="mb-3 text-sm text-stone-700">Ulasan langsung tampil saat dikirim. Gunakan Sembunyikan untuk menyembunyikan sementara, Hapus untuk menghapus permanen.</p>
<div class="card overflow-x-auto">
    <table class="tbl">
        <tr><th>Pelanggan</th><th>Produk</th><th>Bintang</th><th>Komentar</th><th>Status</th><th>Beranda</th><th>Aksi</th></tr>
        @forelse ($reviews as $r)
            <tr>
                <td>{{ $r->user->name }}<br><span class="text-xs text-stone-600">{{ $r->created_at->format('d/m/Y') }}</span></td>
                <td>{{ $r->product->name ?? '(produk dihapus)' }}</td>
                <td>{{ $r->stars() }}</td>
                <td class="max-w-xs">{{ $r->comment }}@if ($r->photo_url)<br><a class="underline" target="_blank" href="{{ $r->photo_url }}">Lihat foto</a>@endif
                    @if ($r->admin_reply)<br><span class="text-xs">Balasan: {{ $r->admin_reply }}</span>@endif
                    <details class="mt-2"><summary class="cursor-pointer underline">Balas</summary>
                        <form method="POST" action="{{ route('admin.ulasan.reply', $r) }}" class="mt-2 grid gap-2">@csrf @method('PATCH')
                            <textarea name="admin_reply" rows="2" class="input" aria-label="Balasan toko">{{ $r->admin_reply }}</textarea>
                            <button class="btn" type="submit">Simpan Balasan</button></form></details></td>
                <td><span class="chip">{{ $r->is_hidden ? 'Disembunyikan' : 'Tampil' }}</span></td>
                <td>
                    @if (!$r->is_hidden)
                        <form method="POST" action="{{ route('admin.ulasan.featured', $r) }}">@csrf @method('PATCH')
                            <button class="underline" type="submit">{{ $r->is_featured ? 'Hapus pilihan' : 'Pilih untuk beranda' }}</button>
                        </form>
                    @else
                        <span class="text-xs text-stone-500">Tidak tersedia</span>
                    @endif
                </td>
                <td><div class="flex flex-col gap-2">
                    <form method="POST" action="{{ route('admin.ulasan.toggle', $r) }}">@csrf @method('PATCH')<button class="underline" type="submit">{{ $r->is_hidden ? 'Tampilkan' : 'Sembunyikan' }}</button></form>
                    <form method="POST" action="{{ route('admin.ulasan.destroy', $r) }}" onsubmit="return confirm('Hapus ulasan ini secara permanen?')">@csrf @method('DELETE')<button class="underline" type="submit">Hapus</button></form></div></td>
            </tr>
        @empty
            <tr><td colspan="7">Belum ada ulasan.</td></tr>
        @endforelse
    </table>
    <div class="mt-4">{{ $reviews->links() }}</div>
</div>
@endsection
