@extends('layouts.admin')
@section('title', 'Pelanggan')
@section('content')
<h1 class="mb-6 text-2xl font-bold">Data Pelanggan</h1>
<form method="GET" class="mb-4"><input class="input w-full max-w-md" type="search" name="q" value="{{ request('q') }}" placeholder="Cari nama, email, atau WhatsApp" aria-label="Cari pelanggan"></form>
<div class="card overflow-x-auto">
    <table class="tbl">
        <tr><th>Nama</th><th>Email</th><th>WhatsApp</th><th>Pesanan</th><th>Servis</th><th>Bergabung</th><th>Aksi</th></tr>
        @forelse ($customers as $c)
            <tr><td>{{ $c->name }}</td><td>{{ $c->email }}</td><td>{{ $c->phone }}</td><td>{{ $c->orders_count }}</td><td>{{ $c->service_requests_count }}</td><td>{{ $c->created_at->format('d/m/Y') }}</td><td><a class="underline" href="{{ route('admin.pelanggan.show', $c) }}">Lihat</a></td></tr>
        @empty
            <tr><td colspan="7">Belum ada pelanggan.</td></tr>
        @endforelse
    </table>
    <div class="mt-4">{{ $customers->links() }}</div>
</div>
@endsection
