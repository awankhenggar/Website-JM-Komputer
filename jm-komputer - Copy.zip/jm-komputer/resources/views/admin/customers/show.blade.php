@extends('layouts.admin')
@section('title', $customer->name)
@section('content')
<h1 class="mb-6 text-2xl font-bold">{{ $customer->name }}</h1>
<div class="grid gap-6 lg:grid-cols-3">
    <div class="card self-start text-sm"><b>Data pelanggan</b><br>{{ $customer->email }}<br>{{ $customer->phone }}<br>Bergabung {{ $customer->created_at->format('d/m/Y') }}<br><a class="underline" target="_blank" rel="noopener" href="https://wa.me/{{ preg_replace('/\D/', '', (string) $customer->phone) }}">Hubungi via WhatsApp</a></div>
    <div class="flex flex-col gap-6 lg:col-span-2">
        <div class="card overflow-x-auto"><b>Riwayat pesanan</b>
            <table class="tbl mt-2"><tr><th>No.</th><th>Tanggal</th><th>Total</th><th>Status</th></tr>
                @forelse ($customer->orders as $o)<tr><td><a class="underline" href="{{ route('admin.pesanan.show', $o) }}">{{ $o->code }}</a></td><td>{{ $o->created_at->format('d/m/Y') }}</td><td>@rp($o->total)</td><td><x-status :model="$o" /></td></tr>@empty<tr><td colspan="4">Belum ada pesanan.</td></tr>@endforelse
            </table></div>
        <div class="card overflow-x-auto"><b>Riwayat servis</b>
            <table class="tbl mt-2"><tr><th>No.</th><th>Perangkat</th><th>Status</th></tr>
                @forelse ($customer->serviceRequests as $s)<tr><td><a class="underline" href="{{ route('admin.servis.show', $s) }}">{{ $s->code }}</a></td><td>{{ $s->brand_model }}</td><td><x-status :model="$s" /></td></tr>@empty<tr><td colspan="3">Belum ada servis.</td></tr>@endforelse
            </table></div>
    </div>
</div>
@endsection
