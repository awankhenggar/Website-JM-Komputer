@extends('layouts.admin')
@section('title', 'Pengaturan Toko')
@section('content')
<h1 class="mb-6 text-2xl font-bold">Pengaturan Toko</h1>
<form method="POST" action="{{ route('admin.pengaturan.update') }}" enctype="multipart/form-data" class="grid max-w-3xl gap-6">
    @csrf @method('PUT')
    <div class="card grid gap-4">
        <b>Informasi toko</b>
        <x-field name="name" label="Nama toko" :value="config('store.name')" required />
        <x-field name="about" label="Tentang toko" type="textarea" :value="config('store.about')" :rows="4" />
        <x-field name="address" label="Alamat lengkap" type="textarea" :value="config('store.address')" :rows="2" />
        <x-field name="hours" label="Jam buka" :value="config('store.hours')" />
        <x-field name="phone" label="Nomor telepon" :value="config('store.phone')" />
        <div>
            <x-field name="logo" label="Logo (maks 2 MB)" type="file" accept="image/*" />
            @if (config('store.logo'))<img src="{{ asset('storage/'.config('store.logo')) }}" alt="Logo saat ini" class="mt-2 h-14">@endif
        </div>
    </div>
    <div class="card grid gap-4">
        <b>WhatsApp &amp; peta</b>
        <x-field name="whatsapp" label="Nomor WhatsApp" :value="config('store.whatsapp')" help="Format 62 tanpa tanda + dan tanpa 0 di depan. Contoh: 6281234567890" />
        <x-field name="maps_embed" label="Tautan peta (embed)" type="url" :value="config('store.maps_embed')" help="Isi dengan isi atribut src dari kode Sematkan peta di Google Maps." />
        <x-field name="maps_link" label="Tautan Google Maps" type="url" :value="config('store.maps_link')" />
    </div>
    <div class="card grid gap-4">
        <b>Pembayaran &amp; aturan</b>
        <x-field name="bank_info" label="Info rekening transfer" type="textarea" :value="config('store.bank_info')" :rows="2" />
        <div class="grid gap-4 md:grid-cols-3">
            <x-field name="payment_hours" label="Batas bayar (jam)" type="number" :value="config('store.payment_hours')" min="1" required />
            <x-field name="return_days" label="Batas retur (hari)" type="number" :value="config('store.return_days')" min="0" required />
            <x-field name="warranty_days" label="Garansi servis (hari)" type="number" :value="config('store.warranty_days')" min="0" />
        </div>
    </div>
    <div><button class="btn btn-primary" type="submit">Simpan Pengaturan</button></div>
</form>
@endsection
