@extends('layouts.admin')
@section('title', 'Servis '.$service->code)
@section('content')
<div class="mb-6 flex items-center gap-3"><h1 class="text-2xl font-bold">Tiket {{ $service->code }}</h1><x-status :model="$service" /></div>
<div class="grid gap-6 lg:grid-cols-2">
    <div class="flex flex-col gap-4">
        <div class="card text-sm"><b>Pelanggan</b><br>{{ $service->user->name }} &middot; {{ $service->user->phone }}<br><a class="underline" target="_blank" rel="noopener" href="https://wa.me/{{ preg_replace('/\D/', '', (string) $service->user->phone) }}">Hubungi via WhatsApp</a></div>
        <div class="card text-sm"><b>Jenis &amp; garansi</b><br>{{ $service->service_type === 'garansi' ? 'Klaim garansi' : 'Servis umum' }}@if ($service->order)<br>Pesanan terkait: {{ $service->order->code }} ({{ $service->order->created_at->format('d/m/Y') }})@endif</div>
        <div class="card text-sm"><b>Perangkat &amp; keluhan</b><br>{{ $service->device_type }} - {{ $service->brand_model }}<p class="mt-1 whitespace-pre-line">{{ $service->complaint }}</p>
            <p class="mt-1 text-xs text-stone-600">Penyerahan: {{ $service->handover === 'datang' ? 'Datang ke toko' : 'Kirim via kurir' }}@if ($service->visit_date) &middot; Jadwal {{ $service->visit_date->format('d/m/Y') }}@endif</p></div>
        <div class="card text-sm"><b>Riwayat</b>@foreach ($service->updates as $u)<div class="mt-2 border-b border-stone-200 pb-2"><span class="text-xs text-stone-600">{{ $u->created_at->format('d/m/Y H:i') }}</span><br><b>{{ \App\Models\ServiceRequest::STATUSES[$u->status] ?? $u->status }}</b>@if ($u->note) - {{ $u->note }}@endif</div>@endforeach</div>
    </div>
    <form method="POST" action="{{ route('admin.servis.update', $service) }}" class="card grid gap-4 self-start">
        @csrf @method('PATCH')
        <b>Perbarui tiket</b>
        <x-select name="status" label="Status" :options="\App\Models\ServiceRequest::STATUSES" :value="$service->status" />
        <x-field name="diagnosis" label="Hasil diagnosa" type="textarea" :value="$service->diagnosis" :rows="4" />
        <x-field name="estimate_cost" label="Estimasi biaya (Rp)" type="number" :value="$service->estimate_cost" min="0" />
        <x-field name="final_cost" label="Biaya akhir / tagihan (Rp)" type="number" :value="$service->final_cost" min="0" help="Isi saat status Selesai. Jika melebihi estimasi lebih dari 20 persen, minta persetujuan ulang pelanggan." />
        <x-field name="admin_notes" label="Catatan internal" type="textarea" :value="$service->admin_notes" :rows="2" />
        <x-field name="note" label="Catatan untuk riwayat (tampil ke pelanggan)" :value="null" />
        <button class="btn btn-primary" type="submit">Simpan</button>
    </form>
</div>
@endsection
