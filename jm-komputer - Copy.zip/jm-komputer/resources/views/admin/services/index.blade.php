@extends('layouts.admin')
@section('title', 'Servis')
@section('content')
<h1 class="mb-6 text-2xl font-bold">Servis</h1>
<form method="GET" class="mb-4 flex flex-wrap gap-3">
    <input class="input w-64" type="search" name="q" value="{{ request('q') }}" placeholder="No. servis atau perangkat" aria-label="Cari servis">
    <select class="input w-64" name="status" aria-label="Status"><option value="">Semua status</option>@foreach (\App\Models\ServiceRequest::STATUSES as $k => $v)<option value="{{ $k }}" @selected(request('status') === $k)>{{ $v }}</option>@endforeach</select>
    <button class="btn" type="submit">Filter</button>
</form>
<div class="card overflow-x-auto">
    <table class="tbl">
        <tr><th>No. servis</th><th>Pelanggan</th><th>Perangkat</th><th>Jenis</th><th>Status</th><th>Aksi</th></tr>
        @forelse ($services as $s)
            <tr><td>{{ $s->code }}</td><td>{{ $s->user->name }}</td><td>{{ $s->brand_model }}</td><td>{{ $s->service_type === 'garansi' ? 'Klaim garansi' : 'Umum' }}</td><td><x-status :model="$s" /></td><td><a class="underline" href="{{ route('admin.servis.show', $s) }}">Detail</a></td></tr>
        @empty
            <tr><td colspan="6">Belum ada tiket servis.</td></tr>
        @endforelse
    </table>
    <div class="mt-4">{{ $services->links() }}</div>
</div>
@endsection
