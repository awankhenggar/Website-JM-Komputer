@extends('layouts.admin')
@section('title', 'Dashboard')
@section('content')
<div class="mb-6"><h1 class="text-2xl font-bold">Halo, {{ auth()->user()->name }}</h1><p class="text-sm text-stone-600">Ringkasan toko hari ini.</p></div>

<div class="mb-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
    <div class="card border-l-4" style="border-left-color:#163B60"><span class="text-xs text-stone-600">Penjualan bulan ini</span><b class="mt-1 block text-xl">@rp($stats['revenue'])</b></div>
    <div class="card border-l-4" style="border-left-color:#4C91C2"><span class="text-xs text-stone-600">Perlu dikemas</span><b class="mt-1 block text-3xl">{{ $stats['to_pack'] }}</b><a class="text-xs underline" href="{{ route('admin.pesanan.index', ['status' => 'dibayar']) }}">Lihat pesanan</a></div>
    <div class="card border-l-4" style="border-left-color:#AEBBC9"><span class="text-xs text-stone-600">Menunggu pembayaran</span><b class="mt-1 block text-3xl">{{ $stats['unpaid'] }}</b></div>
    <div class="card border-l-4" style="border-left-color:#166534"><span class="text-xs text-stone-600">Servis aktif</span><b class="mt-1 block text-3xl">{{ $stats['services_active'] }}</b><a class="text-xs underline" href="{{ route('admin.servis.index') }}">Lihat servis</a></div>
    <div class="card"><span class="text-xs text-stone-600">Total produk</span><b class="mt-1 block text-2xl">{{ $stats['products'] }}</b></div>
    <div class="card"><span class="text-xs text-stone-600">Stok menipis (3 ke bawah)</span><b class="mt-1 block text-2xl">{{ $stats['low_stock'] }}</b></div>
    <div class="card"><span class="text-xs text-stone-600">Pengajuan retur baru</span><b class="mt-1 block text-2xl">{{ $stats['returns_new'] }}</b><a class="text-xs underline" href="{{ route('admin.retur.index') }}">Tinjau</a></div>
    <div class="card"><span class="text-xs text-stone-600">Total ulasan</span><b class="mt-1 block text-2xl">{{ $stats['reviews'] }}</b></div>
</div>

<div class="grid gap-6 lg:grid-cols-2">
    <div class="card overflow-x-auto"><b>Pesanan terbaru</b>
        <table class="tbl mt-3"><tr><th>No.</th><th>Pelanggan</th><th>Total</th><th>Status</th></tr>
            @forelse ($latestOrders as $o)
                <tr><td><a class="underline" href="{{ route('admin.pesanan.show', $o) }}">{{ $o->code }}</a></td><td>{{ $o->user->name }}</td><td>@rp($o->total)</td><td><x-status :model="$o" /></td></tr>
            @empty
                <tr><td colspan="4">Belum ada pesanan.</td></tr>
            @endforelse
        </table></div>
    <div class="card overflow-x-auto"><b>Tiket servis terbaru</b>
        <table class="tbl mt-3"><tr><th>No.</th><th>Pelanggan</th><th>Perangkat</th><th>Status</th></tr>
            @forelse ($latestServices as $s)
                <tr><td><a class="underline" href="{{ route('admin.servis.show', $s) }}">{{ $s->code }}</a></td><td>{{ $s->user->name }}</td><td>{{ $s->brand_model }}</td><td><x-status :model="$s" /></td></tr>
            @empty
                <tr><td colspan="4">Belum ada tiket servis.</td></tr>
            @endforelse
        </table></div>
</div>
@endsection
