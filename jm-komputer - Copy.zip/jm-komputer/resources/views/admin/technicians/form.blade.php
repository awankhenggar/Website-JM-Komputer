@extends('layouts.admin')
@section('title', $technician->exists ? 'Ubah Teknisi' : 'Tambah Teknisi')
@section('content')
<h1 class="mb-6 text-2xl font-bold">{{ $technician->exists ? 'Ubah' : 'Tambah' }} Teknisi</h1>
<form method="POST" enctype="multipart/form-data" action="{{ $technician->exists ? route('admin.tim.update', $technician) : route('admin.tim.store') }}" class="card grid max-w-xl gap-4">
    @csrf
    @if ($technician->exists) @method('PUT') @endif
    <x-field name="name" label="Nama" :value="$technician->name" required />
    <x-field name="title" label="Jabatan" :value="$technician->title" />
    <x-field name="expertise" label="Keahlian" :value="$technician->expertise" />
    <div>
        <x-field name="photo" label="Foto (maks 2 MB)" type="file" accept="image/*" />
        @if ($technician->photo_url)<img src="{{ $technician->photo_url }}" alt="Foto saat ini" class="mt-2 h-24 rounded">@endif
    </div>
    <x-field name="sort_order" label="Urutan tampil (angka kecil tampil lebih dulu)" type="number" :value="$technician->sort_order" min="0" required />
    <x-check name="is_active" label="Tampilkan di halaman Tentang" :checked="(bool) $technician->is_active" />
    <div class="flex gap-3"><button class="btn btn-primary" type="submit">Simpan</button><a class="btn" href="{{ route('admin.tim.index') }}">Batal</a></div>
</form>
@endsection
