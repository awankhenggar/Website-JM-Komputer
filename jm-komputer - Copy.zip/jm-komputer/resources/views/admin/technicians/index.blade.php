@extends('layouts.admin')
@section('title', 'Tim Teknisi')
@section('content')
<div class="mb-6 flex items-center justify-between"><h1 class="text-2xl font-bold">Tim Teknisi</h1><a class="btn btn-primary" href="{{ route('admin.tim.create') }}">+ Tambah Teknisi</a></div>
<p class="mb-4 text-sm text-stone-700">Tampil di halaman Tentang Kami.</p>
<div class="card overflow-x-auto">
    <table class="tbl">
        <tr><th>Foto</th><th>Nama</th><th>Keahlian</th><th>Urutan</th><th>Status</th><th>Aksi</th></tr>
        @forelse ($technicians as $t)
            <tr>
                <td>@if ($t->photo_url)<img src="{{ $t->photo_url }}" alt="" class="h-10 w-12 rounded object-cover">@else<div class="h-10 w-12 rounded bg-stone-200"></div>@endif</td>
                <td>{{ $t->name }}<br><span class="text-xs text-stone-600">{{ $t->title }}</span></td><td>{{ $t->expertise }}</td><td>{{ $t->sort_order }}</td>
                <td><span class="chip">{{ $t->is_active ? 'Tampil' : 'Disembunyikan' }}</span></td>
                <td class="flex gap-3"><a class="underline" href="{{ route('admin.tim.edit', $t) }}">Ubah</a>
                    <form method="POST" action="{{ route('admin.tim.destroy', $t) }}" onsubmit="return confirm('Hapus teknisi ini?')">@csrf @method('DELETE')<button class="underline" type="submit">Hapus</button></form></td>
            </tr>
        @empty
            <tr><td colspan="6">Belum ada data teknisi.</td></tr>
        @endforelse
    </table>
</div>
@endsection
