@extends('layouts.admin')
@section('title', 'Retur & Refund')
@section('content')
<h1 class="mb-6 text-2xl font-bold">Retur &amp; Refund</h1>
<form method="GET" class="mb-4 flex flex-wrap gap-3">
    <select class="input w-56" name="status" aria-label="Status"><option value="">Semua status</option>@foreach (\App\Models\ReturnRequest::STATUSES as $k => $v)<option value="{{ $k }}" @selected(request('status') === $k)>{{ $v }}</option>@endforeach</select>
    <button class="btn" type="submit">Filter</button>
</form>
<div class="card overflow-x-auto">
    <table class="tbl">
        <tr><th>No. pengajuan</th><th>Pesanan</th><th>Pelanggan</th><th>Jenis</th><th>Alasan</th><th>Status</th><th>Aksi</th></tr>
        @forelse ($returns as $r)
            <tr><td>{{ $r->code }}</td><td>{{ $r->order->code }}</td><td>{{ $r->user->name }}</td><td>{{ $r->typeLabel() }}</td><td>{{ $r->reason }}</td><td><x-status :model="$r" /></td><td><a class="underline" href="{{ route('admin.retur.show', $r) }}">Tinjau</a></td></tr>
        @empty
            <tr><td colspan="7">Belum ada pengajuan.</td></tr>
        @endforelse
    </table>
    <div class="mt-4">{{ $returns->links() }}</div>
</div>
@endsection
