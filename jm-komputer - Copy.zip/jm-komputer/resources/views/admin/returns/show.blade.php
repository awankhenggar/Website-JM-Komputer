@extends('layouts.admin')
@section('title', 'Pengajuan '.$ret->code)
@section('content')
<div class="mb-6 flex items-center gap-3"><h1 class="text-2xl font-bold">Pengajuan {{ $ret->code }}</h1><x-status :model="$ret" /></div>
<div class="grid gap-6 lg:grid-cols-2">
    <div class="flex flex-col gap-4">
        <div class="card text-sm"><b>Pengajuan</b><br>{{ $ret->typeLabel() }} &middot; Alasan: {{ $ret->reason }}
            @if ($ret->description)<p class="mt-1 whitespace-pre-line">{{ $ret->description }}</p>@endif
            @if ($ret->photo_url)<a target="_blank" href="{{ $ret->photo_url }}"><img src="{{ $ret->photo_url }}" alt="Foto bukti" class="mt-2 h-32 rounded"></a>@endif</div>
        <div class="card text-sm"><b>Pelanggan</b><br>{{ $ret->user->name }} &middot; {{ $ret->user->phone }}
            <br><a class="underline" target="_blank" rel="noopener" href="https://wa.me/{{ preg_replace('/\D/', '', (string) $ret->user->phone) }}">Hubungi via WhatsApp</a></div>
        <div class="card text-sm"><b>Pesanan <a class="underline" href="{{ route('admin.pesanan.show', $ret->order) }}">{{ $ret->order->code }}</a></b> ({{ $ret->order->statusLabel() }})
            @foreach ($ret->order->items as $i)<br>{{ $i->name }} x {{ $i->qty }}@endforeach
            <br>Total: <b>@rp($ret->order->total)</b></div>
    </div>
    @if ($ret->isFinal())
        <div class="card self-start text-sm"><b>Pengajuan sudah final</b>@if ($ret->admin_note)<p class="mt-1">{{ $ret->admin_note }}</p>@endif @if ($ret->refund_amount)<p class="mt-1">Refund: @rp($ret->refund_amount)</p>@endif</div>
    @else
        <form method="POST" action="{{ route('admin.retur.update', $ret) }}" class="card grid gap-4 self-start">
            @csrf @method('PATCH')
            <b>Keputusan</b>
            <x-select name="status" label="Status" :options="\App\Models\ReturnRequest::STATUSES" :value="$ret->status" />
            <x-field name="admin_note" label="Catatan untuk pelanggan" type="textarea" :value="$ret->admin_note" :rows="3" />
            <x-field name="refund_amount" label="Nominal refund (Rp)" type="number" :value="$ret->refund_amount" min="0" help="Isi saat status Refund selesai, setelah uang dikembalikan ke pelanggan." />
            @if ($ret->type === 'retur')<x-check name="restock" label="Kembalikan stok produk saat disetujui" />@endif
            <button class="btn btn-primary" type="submit">Simpan</button>
            <span class="text-xs text-stone-600">Pembatalan yang disetujui otomatis membatalkan pesanan dan mengembalikan stok. Refund dilakukan manual (transfer) oleh admin.</span>
        </form>
    @endif
</div>
@endsection
