@extends('layouts.admin')
@section('title', 'Laporan')
@section('content')
<h1 class="mb-6 text-2xl font-bold">Laporan</h1>
<form method="GET" class="mb-6 flex flex-wrap items-end gap-3">
    <label class="text-sm">Dari<input class="input mt-1" type="date" name="from" value="{{ $from->format('Y-m-d') }}"></label>
    <label class="text-sm">Sampai<input class="input mt-1" type="date" name="to" value="{{ $to->format('Y-m-d') }}"></label>
    <button class="btn btn-primary" type="submit">Tampilkan</button>
</form>
<div class="mb-8 grid grid-cols-2 gap-4 lg:grid-cols-3">
    <div class="card"><span class="text-xs">Total penjualan (pesanan dibayar)</span><b class="block text-xl">@rp($summary['sales'])</b></div>
    <div class="card"><span class="text-xs">Pesanan dibayar / semua pesanan</span><b class="block text-xl">{{ $summary['orders'] }} / {{ $summary['orders_all'] }}</b></div>
    <div class="card"><span class="text-xs">Pendapatan servis (lunas)</span><b class="block text-xl">@rp($summary['service_revenue'])</b></div>
    <div class="card"><span class="text-xs">Tiket servis</span><b class="block text-xl">{{ $summary['services'] }}</b></div>
    <div class="card"><span class="text-xs">Servis selesai</span><b class="block text-xl">{{ $summary['services_done'] }}</b></div>
</div>
<div class="grid gap-6 lg:grid-cols-2">
    <div class="card overflow-x-auto"><b>Penjualan per hari</b>
        <table class="tbl mt-2"><tr><th>Tanggal</th><th>Pesanan</th><th>Total</th></tr>
            @forelse ($daily as $d)<tr><td>{{ $d->day }}</td><td>{{ $d->orders }}</td><td>@rp($d->total)</td></tr>@empty<tr><td colspan="3">Tidak ada data.</td></tr>@endforelse
        </table></div>
    <div class="card overflow-x-auto"><b>Produk terlaris</b>
        <table class="tbl mt-2"><tr><th>Produk</th><th>Terjual</th><th>Pendapatan</th></tr>
            @forelse ($top as $t)<tr><td>{{ $t->name }}</td><td>{{ $t->sold }}</td><td>@rp($t->revenue)</td></tr>@empty<tr><td colspan="3">Tidak ada data.</td></tr>@endforelse
        </table></div>
</div>
@endsection
