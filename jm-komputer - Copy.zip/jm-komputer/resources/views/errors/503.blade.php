@extends('errors.layout')
@section('code', '503')
@section('title', 'Sedang dalam pemeliharaan')
@section('message', 'Situs sedang dalam pemeliharaan. Silakan kembali beberapa saat lagi.')
