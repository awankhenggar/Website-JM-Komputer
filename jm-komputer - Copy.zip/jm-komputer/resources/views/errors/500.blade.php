@extends('errors.layout')
@section('code', '500')
@section('title', 'Terjadi kesalahan')
@section('message', 'Terjadi kesalahan pada sistem. Coba muat ulang halaman. Jika berlanjut, hubungi kami.')
