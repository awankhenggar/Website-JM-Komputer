<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title') - {{ config('store.name', 'JM Komputer') }}</title>
    <style>
        body { margin: 0; font-family: Inter, Arial, sans-serif; background: #F5F5F4; color: #111827; }
        main { max-width: 480px; margin: 12vh auto; padding: 32px; background: #fff; border: 1px solid #d6d3d1; border-radius: 12px; text-align: center; }
        .code { font-size: 56px; font-weight: 700; color: #1F2937; margin: 0; }
        h1 { font-size: 22px; margin: 8px 0; }
        p { color: #44403c; font-size: 15px; line-height: 1.5; }
        a.btn { display: inline-block; margin-top: 16px; padding: 12px 20px; background: #1F2937; color: #fff; border-radius: 8px; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
<main>
    <p class="code">@yield('code')</p>
    <h1>@yield('title')</h1>
    <p>@yield('message')</p>
    <a class="btn" href="{{ url('/') }}">Ke Beranda</a>
</main>
</body>
</html>
