@extends('errors.layout')
@section('code', '419')
@section('title', 'Sesi berakhir')
@section('message', 'Sesi Anda sudah berakhir. Muat ulang halaman lalu coba lagi.')
