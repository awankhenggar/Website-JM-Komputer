<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'Panel Admin') - {{ config('store.name') }}</title>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="font-sans antialiased">
@php
    $pendingOrdersCount = auth()->user()->isAdmin()
        ? \App\Models\Order::whereNotIn('status', ['selesai', 'batal'])->count()
        : 0;
    $menu = auth()->user()->isAdmin()
        ? [
            ['admin.dashboard', 'Dashboard', 'admin.dashboard'],
            ['admin.produk.index', 'Produk & Stok', 'admin.produk.*'],
            ['admin.kategori.index', 'Kategori', 'admin.kategori.*'],
            ['admin.pesanan.index', 'Pesanan', 'admin.pesanan.*'],
            ['admin.retur.index', 'Retur & Refund', 'admin.retur.*'],
            ['admin.pelanggan.index', 'Pelanggan', 'admin.pelanggan.*'],
            ['admin.servis.index', 'Servis', 'admin.servis.*'],
            ['admin.ulasan.index', 'Ulasan', 'admin.ulasan.*'],
            ['admin.layanan.index', 'Layanan Servis', 'admin.layanan.*'],
            ['admin.tim.index', 'Tim Teknisi', 'admin.tim.*'],
            ['admin.laporan.index', 'Laporan', 'admin.laporan.*'],
            ['admin.pengguna.index', 'Manajemen Admin', 'admin.pengguna.*'],
            ['admin.pengaturan.edit', 'Pengaturan Toko', 'admin.pengaturan.*'],
        ]
        : [['admin.servis.index', 'Servis', 'admin.servis.*']];
@endphp
<div class="flex min-h-screen flex-col md:flex-row">
    <aside class="bg-brand-dark text-stone-200 md:sticky md:top-0 md:h-screen md:w-64 md:shrink-0 md:overflow-y-auto">
        <div class="flex items-center justify-between gap-3 px-5 py-4 md:block">
            <a href="{{ route('home') }}" class="flex items-center gap-2.5 text-lg font-extrabold text-white" aria-label="{{ config('store.name') }} - Beranda">
                <img src="{{ config('store.logo') ? asset('storage/'.config('store.logo')) : asset('images/jm-logo.png') }}" alt="" class="h-11 w-11 shrink-0 object-contain">
                <span class="leading-tight">{{ config('store.name') }}</span>
            </a>
            <p class="mt-1 hidden text-xs text-stone-400 md:block">Panel {{ auth()->user()->role }}</p>
        </div>
        <nav class="flex gap-1 overflow-x-auto px-3 pb-3 text-sm md:flex-col md:overflow-visible md:pb-6" aria-label="Menu admin">
            @foreach ($menu as [$route, $label, $pattern])
                @php $active = request()->routeIs($pattern); @endphp
                <a href="{{ route($route) }}" class="shrink-0 whitespace-nowrap rounded-lg px-3 py-2 transition hover:bg-white/10 {{ $active ? 'bg-accent font-semibold text-white' : '' }}">{{ $label }}
                    @if ($route === 'admin.pesanan.index' && $pendingOrdersCount > 0)
                        <span class="ml-2 inline-flex min-w-5 items-center justify-center rounded-full bg-rose-500 px-1.5 py-0.5 text-[10px] font-extrabold leading-none text-white">{{ $pendingOrdersCount > 99 ? '99+' : $pendingOrdersCount }}</span>
                    @endif
                </a>
            @endforeach
            <form method="POST" action="{{ route('logout') }}" class="md:mt-4">@csrf<button type="submit" class="shrink-0 whitespace-nowrap rounded-lg px-3 py-2 text-left text-stone-400 hover:bg-white/10 hover:text-white">Keluar</button></form>
        </nav>
    </aside>
    <div class="min-w-0 flex-1 admin-surface">
        <div class="flex items-center justify-between border-b border-slate-200 bg-white px-6 py-3 text-sm shadow-[0_2px_10px_rgba(11,31,54,0.03)]">
            <span class="font-semibold">@yield('title', 'Panel Admin')</span>
            <span class="text-stone-600">{{ auth()->user()->name }}</span>
        </div>
        <main class="p-6">
            @include('partials.flash')
            @yield('content')
        </main>
    </div>
</div>
</body>
</html>
