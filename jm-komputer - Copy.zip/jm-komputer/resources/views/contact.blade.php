@extends('layouts.app')
@section('title', 'Kontak & Lokasi')
@section('content')
<h1 class="mb-6 text-3xl font-bold">Kontak &amp; Lokasi</h1>
<div class="grid gap-6 md:grid-cols-2">
    <div>
        @if (config('store.maps_embed'))
            <iframe src="{{ config('store.maps_embed') }}" class="h-80 w-full rounded-xl border border-stone-300" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="Lokasi {{ config('store.name') }}"></iframe>
        @else
            <div class="flex h-80 items-center justify-center rounded-xl bg-stone-200 text-sm text-stone-600">Peta belum diatur (isi STORE_MAPS_EMBED di .env)</div>
        @endif
    </div>
    <div class="card flex flex-col gap-3 text-sm">
        <b class="text-lg">{{ config('store.name') }}</b>
        <span>{{ config('store.address') }}</span>
        <span>{{ config('store.hours') }}</span>
        <span>Telepon: {{ config('store.phone') }}</span>
        <a class="btn btn-accent" target="_blank" rel="noopener" href="https://wa.me/{{ config('store.whatsapp') }}?text={{ urlencode('Halo '.config('store.name').', saya ingin konsultasi.') }}">Konsultasi via WhatsApp</a>
        <a class="btn" target="_blank" rel="noopener" href="{{ config('store.maps_link') }}">Buka di Maps</a>
    </div>
</div>
@endsection
