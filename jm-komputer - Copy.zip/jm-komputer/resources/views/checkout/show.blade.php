@extends('layouts.app')
@section('title', 'Checkout')
@section('content')
<h1 class="mb-6 text-3xl font-bold">Checkout</h1>
<div class="grid gap-6 md:grid-cols-3">
    <form method="POST" action="{{ route('checkout.store') }}" class="card grid gap-4 md:col-span-2">
        @csrf
        @foreach ($selectedIds as $selectedId)
            <input type="hidden" name="selected[]" value="{{ $selectedId }}">
        @endforeach
        <b>Alamat pengiriman</b>
        <x-field name="recipient_name" label="Nama penerima" :value="$user->name" required />
        <x-field name="phone" label="Nomor telepon / WhatsApp" :value="$user->phone" required />
        <x-field name="address" label="Alamat lengkap" type="textarea" />
        <x-field name="city" label="Kota / kecamatan" />
        <x-field name="notes" label="Catatan untuk toko (opsional)" type="textarea" :rows="2" />
        <div class="rounded-lg bg-stone-100 p-3 text-sm">
            <b>Pembayaran: transfer bank</b><br>{{ config('store.bank_info') }}<br>
            Pesanan dibatalkan otomatis jika belum dibayar dalam {{ config('store.payment_hours', 24) }} jam. Ongkir ditentukan toko dan ditambahkan ke total setelah pesanan dibuat.
        </div>
        <button class="btn btn-accent" type="submit">Buat Pesanan</button>
    </form>
    <aside class="card self-start">
        <b>Ringkasan pesanan terpilih</b>
        @foreach ($items as $item)
            <div class="mt-2 flex justify-between gap-2 text-sm"><span>{{ $item['product']->name }} x {{ $item['qty'] }}</span><span>@rp($item['product']->price * $item['qty'])</span></div>
        @endforeach
        <div class="mt-3 flex justify-between border-t border-stone-300 pt-3"><b>Subtotal</b><b>@rp($subtotal)</b></div>
    </aside>
</div>
@endsection
