@props(['model'])
@php
    $s = $model->status;
    $tone = match (true) {
        in_array($s, ['batal', 'dibatalkan', 'ditolak'], true) => 'red',
        in_array($s, ['lunas', 'refund_selesai'], true) => 'green',
        $s === 'selesai' => $model instanceof \App\Models\ServiceRequest ? 'amber' : 'green',
        in_array($s, ['dibayar', 'dikirim', 'dikerjakan', 'disetujui'], true) => 'blue',
        in_array($s, ['menunggu_bayar', 'menunggu_persetujuan', 'diagnosa', 'diproses', 'dikemas'], true) => 'amber',
        default => 'gray',
    };
@endphp
<span class="chip chip-{{ $tone }}">{{ $model->statusLabel() }}</span>
