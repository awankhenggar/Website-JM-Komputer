@props(['name', 'label', 'checked' => false])
<label class="flex items-center gap-2 text-sm">
    <input type="checkbox" name="{{ $name }}" value="1" @checked(session()->hasOldInput() ? old($name) : $checked)>
    {{ $label }}
</label>
