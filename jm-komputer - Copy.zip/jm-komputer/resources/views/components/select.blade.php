@props(['name', 'label', 'options' => [], 'value' => null, 'blank' => null])
<div>
    <label for="{{ $name }}" class="mb-1 block text-sm font-medium">{{ $label }}</label>
    <select id="{{ $name }}" name="{{ $name }}" class="input" {{ $attributes }}>
        @if ($blank !== null)
            <option value="">{{ $blank }}</option>
        @endif
        @foreach ($options as $k => $v)
            <option value="{{ $k }}" @selected((string) old($name, $value) === (string) $k)>{{ $v }}</option>
        @endforeach
    </select>
    @error($name)
        <p class="mt-1 text-sm text-red-700" role="alert">{{ $message }}</p>
    @enderror
</div>
