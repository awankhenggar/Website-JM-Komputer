@props(['name', 'label', 'type' => 'text', 'value' => null, 'rows' => 3, 'help' => null])
<div>
    <label for="{{ $name }}" class="mb-1 block text-sm font-medium">{{ $label }}</label>
    @if ($type === 'textarea')
        <textarea id="{{ $name }}" name="{{ $name }}" rows="{{ $rows }}" class="input">{{ old($name, $value) }}</textarea>
    @elseif ($type === 'password')
        <div class="password-field">
            <input id="{{ $name }}" name="{{ $name }}" type="password" value="" class="input" {{ $attributes }}>
            <button type="button" class="password-toggle" data-toggle-password aria-label="Tampilkan password" aria-pressed="false" title="Tampilkan password">
                <svg class="icon-eye" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg>
                <svg class="icon-eye-off" viewBox="0 0 24 24" aria-hidden="true"><path d="M10.73 5.08A10.74 10.74 0 0 1 21.94 11.65a1 1 0 0 1 0 .7 10.75 10.75 0 0 1-1.44 2.49M14.08 14.16a3 3 0 0 1-4.24-4.24M17.48 17.5a10.75 10.75 0 0 1-15.42-5.15 1 1 0 0 1 0-.7 10.75 10.75 0 0 1 4.45-5.14M2 2l20 20"/></svg>
            </button>
        </div>
    @else
        <input id="{{ $name }}" name="{{ $name }}" type="{{ $type }}" value="{{ old($name, $value) }}" class="input" {{ $attributes }}>
    @endif
    @if ($help)
        <p class="mt-1 text-xs text-stone-600">{{ $help }}</p>
    @endif
    @error($name)
        <p class="mt-1 text-sm text-red-700" role="alert">{{ $message }}</p>
    @enderror
</div>
