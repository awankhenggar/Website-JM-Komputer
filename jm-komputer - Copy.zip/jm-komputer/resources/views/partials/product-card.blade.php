<div class="card card-hover group flex flex-col overflow-hidden p-0">
    <a href="{{ route('products.show', $product->slug) }}" class="relative block overflow-hidden bg-stone-100">
        @if ($product->image_url)
            <img src="{{ $product->image_url }}" alt="{{ $product->name }}" data-cart-product-image class="h-44 w-full object-cover transition duration-300 group-hover:scale-105">
        @else
            <div class="flex h-44 items-center justify-center text-sm text-stone-500">Foto produk</div>
        @endif
        <div class="absolute left-2 top-2 flex gap-1">
            @if ($product->is_featured)<span class="badge">Unggulan</span>@endif
            @if ($product->stock > 0 && $product->stock <= 3)<span class="badge-accent">Sisa {{ $product->stock }}</span>@endif
        </div>
    </a>
    <div class="flex flex-1 flex-col gap-1 p-4">
        <span class="text-xs text-stone-500">{{ $product->category->name ?? '' }}</span>
        <a href="{{ route('products.show', $product->slug) }}" class="font-semibold leading-snug hover:underline">{{ $product->name }}</a>
        <b class="mt-1 text-lg text-accent">@rp($product->price)</b>
        @if ($product->stock > 0)
            <form method="POST" action="{{ route('cart.add', $product) }}" data-cart-add class="mt-auto pt-3">
                @csrf
                <button class="btn btn-primary w-full" type="submit">+ Keranjang</button>
            </form>
        @else
            <span class="chip chip-red mt-1 w-fit">Stok habis</span>
            <button class="btn mt-auto w-full" type="button" disabled>Stok Habis</button>
        @endif
    </div>
</div>
