@if (session('success'))
    <div role="status" class="mb-4 rounded-xl border border-green-200 bg-green-50 p-3 text-sm text-green-900">{{ session('success') }}</div>
@endif
@if (session('error'))
    <div role="alert" class="mb-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-900">{{ session('error') }}</div>
@endif
@error('cart')
    <div role="alert" class="mb-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-900">{{ $message }}</div>
@enderror
