@extends('layouts.app')
@section('title', 'Atur Ulang Password')
@section('content')
<div class="mx-auto grid max-w-4xl overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-sm md:grid-cols-2">
    @include('auth._panel')
    <form method="POST" action="{{ route('password.update') }}" class="grid content-center gap-4 p-6 md:p-10">
        @csrf
        <input type="hidden" name="token" value="{{ $token }}">
        <h1 class="text-2xl font-bold">Atur Ulang Password</h1>
        <x-field name="email" label="Email" type="email" :value="$email" required />
        <x-field name="password" label="Password baru (minimal 8 karakter)" type="password" required />
        <x-field name="password_confirmation" label="Konfirmasi password baru" type="password" required />
        <button class="btn btn-primary" type="submit">Simpan Password</button>
        <p class="text-center text-sm"><a class="underline" href="{{ route('password.request') }}">Minta tautan baru</a></p>
    </form>
</div>
@endsection
