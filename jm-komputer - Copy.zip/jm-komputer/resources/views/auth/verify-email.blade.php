@extends('layouts.app')
@section('title', 'Verifikasi Email')
@section('content')
<div class="mx-auto max-w-md">
    <div class="card grid gap-4">
        <h1 class="text-2xl font-bold">Cek email Anda</h1>
        <p class="text-sm">Tautan verifikasi dikirim ke <b>{{ auth()->user()->email }}</b>. Anda tetap bisa berbelanja, tetapi pesanan diproses setelah email diverifikasi.</p>
        <form method="POST" action="{{ route('verification.send') }}">@csrf<button class="btn btn-primary w-full" type="submit">Kirim Ulang Email</button></form>
        <a class="btn" href="{{ route('products.index') }}">Lanjut Belanja</a>
    </div>
</div>
@endsection
