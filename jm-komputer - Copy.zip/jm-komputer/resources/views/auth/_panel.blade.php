<div class="auth-panel hero-bg hidden text-white md:flex">
    <div class="auth-panel-intro">
        <b class="text-2xl font-extrabold">{{ config('store.name') }}</b>
        <p class="mt-3 text-sm text-stone-300">Belanja laptop dan komputer, booking servis, dan pantau pesanan Anda di satu tempat.</p>
    </div>
    <ul class="auth-benefits grid gap-2 text-sm text-stone-200">
        <li>&#10003; Pantau status pesanan dan servis</li>
        <li>&#10003; Riwayat belanja tersimpan</li>
        <li>&#10003; Konsultasi gratis via WhatsApp</li>
    </ul>
</div>
