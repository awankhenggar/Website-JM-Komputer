@extends('layouts.app')
@section('title', 'Lupa Password')
@section('content')
<div class="mx-auto grid max-w-4xl overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-sm md:grid-cols-2">
    @include('auth._panel')
    <form method="POST" action="{{ route('password.email') }}" class="grid content-center gap-4 p-6 md:p-10">
        @csrf
        <div><h1 class="text-2xl font-bold">Lupa Password</h1><p class="text-sm text-stone-600">Masukkan email akun Anda. Kami mengirim tautan untuk membuat password baru.</p></div>
        <x-field name="email" label="Email" type="email" required autofocus />
        <button class="btn btn-primary" type="submit">Kirim Tautan</button>
        <p class="text-center text-sm"><a class="underline" href="{{ route('login') }}">Kembali ke halaman masuk</a></p>
    </form>
</div>
@endsection
