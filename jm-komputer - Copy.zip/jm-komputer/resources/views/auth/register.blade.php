@extends('layouts.app')
@section('title', 'Daftar')
@section('content')
<div class="auth-card auth-card-register mx-auto grid overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-sm md:grid-cols-2">
    @include('auth._panel')
    <form method="POST" action="{{ route('register') }}" class="auth-form auth-form-register grid content-center gap-3 p-6 md:p-8">
        @csrf
        <div class="auth-heading"><h1 class="text-2xl font-bold">Daftar Akun</h1><p class="text-sm text-stone-600">Gratis, hanya butuh beberapa detik.</p></div>
        <div class="grid gap-x-3 gap-y-2.5 lg:grid-cols-2">
            <div class="lg:col-span-2"><x-field name="name" label="Nama lengkap" required /></div>
            <x-field name="email" label="Email" type="email" required />
            <x-field name="phone" label="Nomor WhatsApp" type="tel" required />
            <x-field name="password" label="Password (min. 8 karakter)" type="password" required />
            <x-field name="password_confirmation" label="Konfirmasi password" type="password" required />
        </div>
        <button class="btn btn-primary" type="submit">Daftar</button>
        <p class="text-center text-sm">Sudah punya akun? <a class="font-semibold underline" href="{{ route('login') }}">Masuk</a></p>
    </form>
</div>
@endsection
