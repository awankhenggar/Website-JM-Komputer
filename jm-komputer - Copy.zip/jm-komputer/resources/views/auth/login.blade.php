@extends('layouts.app')
@section('title', 'Masuk')
@section('content')
<div class="auth-card mx-auto grid overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-sm md:grid-cols-2">
    @include('auth._panel')
    <form method="POST" action="{{ route('login') }}" class="auth-form grid content-center gap-4 p-6 md:p-8">
        @csrf
        <div class="auth-heading"><h1 class="text-2xl font-bold">Masuk</h1><p class="text-sm text-stone-600">Selamat datang kembali.</p></div>
        <x-field name="email" label="Email" type="email" required autofocus />
        <x-field name="password" label="Password" type="password" required />
        <div class="flex items-center justify-between gap-3">
            <x-check name="remember" label="Ingat saya" />
            <a class="text-sm underline" href="{{ route('password.request') }}">Lupa password?</a>
        </div>
        <button class="btn btn-primary" type="submit">Masuk</button>
        <p class="text-center text-sm">Belum punya akun? <a class="font-semibold underline" href="{{ route('register') }}">Daftar</a></p>
    </form>
</div>
@endsection
