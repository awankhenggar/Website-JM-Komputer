<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', config('store.name'))</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="font-sans antialiased">
@php
    $nav = [
        [route('home'), 'Beranda', request()->routeIs('home')],
        [route('products.index'), 'Produk', request()->routeIs('products.*')],
        [route('services'), 'Layanan Servis', request()->routeIs('services')],
        [route('reviews.index'), 'Ulasan', request()->routeIs('reviews.*')],
        [route('about'), 'Tentang', request()->routeIs('about')],
        [route('contact'), 'Kontak', request()->routeIs('contact')],
    ];
    $wa = 'https://wa.me/'.config('store.whatsapp').'?text='.urlencode('Halo '.config('store.name').', saya ingin konsultasi.');
@endphp

<div class="hidden bg-brand-dark text-xs text-stone-300 md:block">
    <div class="mx-auto flex max-w-6xl items-center justify-between px-4 py-1.5">
        <span>{{ config('store.hours') }}</span>
        <a href="{{ $wa }}" target="_blank" rel="noopener" class="hover:text-white">Konsultasi gratis via WhatsApp</a>
    </div>
</div>

<header class="site-header sticky top-0 z-30">
    <div class="site-header-inner mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3">
        <a href="{{ route('home') }}" class="site-brand flex shrink-0 items-center gap-2 text-xl font-extrabold" aria-label="{{ config('store.name') }} - Beranda">
            @if (config('store.logo'))
                <img src="{{ asset('storage/'.config('store.logo')) }}" alt="{{ config('store.name') }}" class="h-10 w-auto">
            @else
                <span class="flex h-9 w-9 items-center justify-center rounded-md bg-blue-600 text-sm font-extrabold text-white">{{ strtoupper(substr(config('store.name'), 0, 2)) }}</span>
                <span>{{ config('store.name') }}</span>
            @endif
        </a>

        <nav class="site-nav hidden items-center gap-6 text-sm font-semibold md:flex" aria-label="Menu utama">
            @foreach ($nav as [$url, $label, $active])
                <a href="{{ $url }}" class="site-nav-link {{ $active ? 'is-active' : '' }}">{{ $label }}</a>
            @endforeach
        </nav>

        <div class="site-actions flex shrink-0 items-center gap-2">
            <form action="{{ route('products.index') }}" method="GET" class="hidden lg:block">
                <input class="site-search input w-44" type="search" name="q" placeholder="Cari produk..." aria-label="Cari produk" value="{{ request('q') }}">
            </form>
            <a class="site-cart" href="{{ route('cart.index') }}" aria-label="Keranjang belanja, {{ \App\Support\Cart::count() }} produk" title="Keranjang belanja">
                <svg viewBox="0 0 24 24" aria-hidden="true" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="9" cy="21" r="1"></circle><circle cx="19" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                </svg>
                @if (\App\Support\Cart::count() > 0)
                    <span class="site-cart-count">{{ \App\Support\Cart::count() > 99 ? '99+' : \App\Support\Cart::count() }}</span>
                @endif
            </a>
            @auth
                <a class="site-auth-link hidden sm:inline-flex" href="{{ auth()->user()->isStaff() ? (auth()->user()->isAdmin() ? route('admin.dashboard') : route('admin.servis.index')) : route('account.index') }}">{{ auth()->user()->isStaff() ? 'Panel Admin' : 'Akun Saya' }}</a>
                <form method="POST" action="{{ route('logout') }}" class="hidden sm:block">@csrf<button class="site-auth-link" type="submit">Keluar</button></form>
            @else
                <a class="site-auth-link hidden sm:inline-flex" href="{{ route('login') }}">Masuk</a>
                <a class="site-register-link hidden sm:inline-flex" href="{{ route('register') }}">Daftar</a>
            @endauth
        </div>
    </div>

    <details class="site-mobile-menu md:hidden">
        <summary class="cursor-pointer list-none px-4 py-3 text-sm font-semibold">Menu <span aria-hidden="true">⌄</span></summary>
        <div class="grid gap-1 px-4 pb-4 text-sm">
            <form action="{{ route('products.index') }}" method="GET" class="mb-2"><input class="input" type="search" name="q" placeholder="Cari produk..." aria-label="Cari produk"></form>
            @foreach ($nav as [$url, $label, $active])
                <a href="{{ $url }}" class="site-mobile-link {{ $active ? 'is-active' : '' }}">{{ $label }}</a>
            @endforeach
            @auth
                <a href="{{ auth()->user()->isStaff() ? (auth()->user()->isAdmin() ? route('admin.dashboard') : route('admin.servis.index')) : route('account.index') }}" class="site-mobile-link">{{ auth()->user()->isStaff() ? 'Panel Admin' : 'Akun Saya' }}</a>
                <form method="POST" action="{{ route('logout') }}">@csrf<button class="site-mobile-link w-full text-left" type="submit">Keluar</button></form>
            @else
                <a href="{{ route('login') }}" class="site-mobile-link">Masuk</a>
                <a href="{{ route('register') }}" class="site-mobile-link">Daftar</a>
            @endauth
        </div>
    </details>
</header>

@auth
    @if (auth()->user()->role === 'pelanggan' && ! auth()->user()->hasVerifiedEmail())
        <div class="border-b border-amber-200 bg-amber-50 text-sm text-amber-900">
            <div class="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-2">
                <span>Email Anda belum diverifikasi. Anda tetap bisa berbelanja, tetapi pesanan diproses setelah email diverifikasi.</span>
                <form method="POST" action="{{ route('verification.send') }}">@csrf<button class="font-semibold underline" type="submit">Kirim ulang email</button></form>
            </div>
        </div>
    @endif
@endauth

<main class="mx-auto max-w-6xl px-4 py-8">
    @include('partials.flash')
    @yield('content')
</main>

<footer class="mt-12 bg-brand-dark text-stone-300">
    <div class="mx-auto grid max-w-6xl gap-8 px-4 py-10 md:grid-cols-4">
        <div class="md:col-span-2">
            <b class="text-lg text-white">{{ config('store.name') }}</b>
            <p class="mt-2 max-w-md text-sm">{{ \Illuminate\Support\Str::limit(config('store.about'), 160) }}</p>
            <p class="mt-3 text-sm">{{ config('store.address') }}<br>{{ config('store.hours') }}<br>Telepon: {{ config('store.phone') }}</p>
        </div>
        <div class="text-sm">
            <b class="text-white">Menu</b>
            <ul class="mt-2 grid gap-1">
                <li><a class="hover:text-white" href="{{ route('products.index') }}">Produk</a></li>
                <li><a class="hover:text-white" href="{{ route('services') }}">Layanan Servis</a></li>
                <li><a class="hover:text-white" href="{{ route('booking.create') }}">Booking Servis</a></li>
                <li><a class="hover:text-white" href="{{ route('reviews.index') }}">Ulasan</a></li>
                <li><a class="hover:text-white" href="{{ route('contact') }}">Kontak &amp; Lokasi</a></li>
            </ul>
        </div>
        <div class="text-sm">
            <b class="text-white">Butuh bantuan?</b>
            <p class="mt-2">Tanyakan produk atau servis langsung ke kami.</p>
            <a class="btn btn-accent mt-3" href="{{ $wa }}" target="_blank" rel="noopener">Konsultasi via WhatsApp</a>
        </div>
    </div>
    <div class="border-t border-white/10 py-4 text-center text-xs text-stone-400">&copy; {{ date('Y') }} {{ config('store.name') }}. Semua hak dilindungi.</div>
</footer>
</body>
</html>
