# JM Komputer - kode sumber (Laravel 12)

Berkas di folder ini adalah lapisan di atas proyek Laravel 12 baru. Gabungkan (timpa) ke proyekmu.

## Langkah pemasangan

1. Buat proyek baru (PHP 8.2 dipakai apa adanya):

       composer create-project laravel/laravel:^12.0 jm-komputer
       cd jm-komputer

2. Salin SEMUA isi folder ini ke dalam folder `jm-komputer`, timpa berkas yang sama
   (yang tertimpa: app/Models/User.php, app/Providers/AppServiceProvider.php,
   resources/css/app.css, routes/console.php, routes/web.php, database/seeders/DatabaseSeeder.php).

3. Buat database kosong `jm_komputer` di MySQL, lalu ubah `.env`:

       APP_NAME="JM Komputer"
       APP_TIMEZONE=Asia/Jakarta
       DB_CONNECTION=mysql
       DB_HOST=127.0.0.1
       DB_PORT=3306
       DB_DATABASE=jm_komputer
       DB_USERNAME=root
       DB_PASSWORD=

       STORE_NAME="JM Komputer"
       STORE_ABOUT="Isi deskripsi toko di sini."
       STORE_ADDRESS="Alamat lengkap toko"
       STORE_HOURS="Senin - Sabtu, 09.00 - 17.00"
       STORE_PHONE="08xxxxxxxxxx"
       STORE_WHATSAPP=628xxxxxxxxxx
       STORE_MAPS_EMBED="https://www.google.com/maps/embed?pb=...."
       STORE_MAPS_LINK="https://maps.app.goo.gl/...."
       STORE_BANK_INFO="Nama bank - nomor rekening - atas nama"

   STORE_MAPS_EMBED diisi isi atribut src dari kode "Sematkan peta" di Google Maps.
   STORE_WHATSAPP memakai format 62 tanpa tanda + dan tanpa angka 0 di depan.

4. Jalankan:

       php artisan migrate --seed
       php artisan storage:link
       npm install
       npm run dev          (biarkan terbuka, buka terminal kedua)
       php artisan serve

5. Buka http://127.0.0.1:8000

## Akun contoh (ganti password sebelum hosting)

| Peran | Email | Password |
|---|---|---|
| Admin | admin@jmkomputer.test | password |
| Teknisi | teknisi@jmkomputer.test | password |
| Pelanggan | pelanggan@jmkomputer.test | password |

Admin masuk ke /admin. Teknisi hanya ke /admin/servis.

## Pembatalan otomatis pesanan 24 jam

Perintah `php artisan orders:cancel-expired` membatalkan pesanan yang belum dibayar lebih dari 24 jam
dan mengembalikan stok. Terjadwal tiap jam. Saat pengembangan jalankan `php artisan schedule:work`.
Di hosting, tambahkan cron: `* * * * * cd /path/jm-komputer && php artisan schedule:run >> /dev/null 2>&1`

## Belum termasuk (tahap berikutnya)

Payment gateway, ongkir lewat API, ulasan, lupa password dan verifikasi email, retur dan refund,
pesanan/servis manual di toko, tim teknisi, kelola layanan servis dan pengaturan toko dari admin.
